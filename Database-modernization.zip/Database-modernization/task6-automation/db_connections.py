import pyodbc
import mysql.connector
import psycopg2

from config import MYSQL_CONFIG, POSTGRES_CONFIG, MSSQL_CONFIG


# ---------------- MSSQL ----------------
def connect_mssql():
    conn_str = (
        f"DRIVER={{{MSSQL_CONFIG['driver']}}};"
        f"SERVER={MSSQL_CONFIG['server']};"
        f"DATABASE={MSSQL_CONFIG['database']};"
        f"Trusted_Connection={MSSQL_CONFIG['trusted_connection']};"
    )
    return pyodbc.connect(conn_str)


# ---------------- MYSQL ----------------
def connect_mysql(database=None):
    config = MYSQL_CONFIG.copy()
    if database:
        config["database"] = database
    return mysql.connector.connect(**config)


# ---------------- POSTGRES ----------------

def connect_postgres(database="postgres"):
    return psycopg2.connect(
        host="localhost",
        port=5433,
        user="postgres",
        password="1234",
        dbname=database   # IMPORTANT: correct keyword usage
    )