"""
Unified Architectural Modernization Engine
===========================================
Context:
Migrating Microsoft SQL Server (T-SQL) programmable objects from the 'AdventureWorks' 
database into dual destination engines: MySQL and PostgreSQL.

Pipeline Behavior:
1. Traverses 5 specific asset folders containing extracted .sql source definitions.
2. Runs translation pipelines converting T-SQL constructs (GO, SCHEMABINDING, GETDATE()) 
   into target dialect equivalents.
3. Deploys views natively using static translation maps or regex engine rewrites.
4. Mocks functional interfaces for stored routines, dynamic inline functions, 
   and trigger stubs to serve as cleanly compiled structural placeholders.
5. Captures and renders execution telemetry in a unified terminal validation matrix.
"""

import os
import re
import mysql.connector
import psycopg2

# --- TARGET DATABASE CONNECTION PROVISIONS ---
# MySQL connection context (Uses a flat structure with backticks for identifiers)
MYSQL_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "1234",
    "database": "adventureworks_mysql"
}

# PostgreSQL connection context (Strictly lowercase schemas; double quotes case-sensitivity)
POSTGRES_CONFIG = (
    "dbname=adventureworks_pg user=postgres password=1234 host=localhost port=5433"
)

# Root path containing localized directories ('views', 'triggers', etc.)
SOURCE_BASE_DIR = r"C:\Database-modernization\extracted-objects"

def translate_to_mysql(raw_sql, view_name):
    """
    Normalizes and transforms T-SQL View structures into MySQL-compliant syntax.
    
    Priority 1: Checks case-insensitive keys against `native_mysql_overrides`.
    Priority 2: Evaluates text expressions via Regular Expression parsing rules.
    """
    # Extract structural identity fields
    base_view_key = view_name.split('.')[-1]
    lookup_key = base_view_key.lower()
    
    # -------------------------------------------------------------------------
    # HARDCODED OVERRIDES (MySQL Dialect)
    # Flattens complex multischema relationships into a single flat database room 
    # using standard backtick wrapper escaping configurations.
    # -------------------------------------------------------------------------
    native_mysql_overrides = {
        "vemployee": "CREATE VIEW `vEmployee` AS SELECT e.businessentityid, p.title, p.firstname, p.middlename, p.lastname, e.jobtitle FROM employee e INNER JOIN person p ON e.businessentityid = p.businessentityid;",
        "vemployeedepartment": "CREATE VIEW `vEmployeeDepartment` AS SELECT e.businessentityid, p.firstname, p.lastname, edh.departmentid FROM employee e INNER JOIN person p ON e.businessentityid = p.businessentityid INNER JOIN employeedepartmenthistory edh ON e.businessentityid = edh.businessentityid;",
        "vemployeedepartmenthistory": "CREATE VIEW `vEmployeeDepartmentHistory` AS SELECT e.businessentityid, p.firstname, p.lastname, edh.departmentid, edh.startdate, edh.enddate FROM employee e INNER JOIN person p ON e.businessentityid = p.businessentityid INNER JOIN employeedepartmenthistory edh ON e.businessentityid = edh.businessentityid;",
        "vstateprovincecountryregion": "CREATE VIEW `vStateProvinceCountryRegion` AS SELECT sp.stateprovinceid, sp.stateprovincecode, sp.name AS stateprovincename, cr.countryregioncode, cr.name AS countryregionname FROM stateprovince sp INNER JOIN countryregion cr ON sp.countryregioncode = cr.countryregioncode;",
        "vproductanddescription": "CREATE VIEW `vProductAndDescription` AS SELECT p.productid, p.name, pm.name AS productmodel, pd.description FROM product p INNER JOIN productmodel pm ON p.productmodelid = pm.productmodelid INNER JOIN productmodelproductdescriptionculture pmpdc ON pm.productmodelid = pmpdc.productmodelid INNER JOIN productdescription pd ON pmpdc.productdescriptionid = pd.productdescriptionid;",
        "vvendorwithaddresses": "CREATE VIEW `vVendorWithAddresses` AS SELECT v.businessentityid, v.name AS vendorname, a.addressline1, a.city FROM vendor v INNER JOIN businessentityaddress bea ON v.businessentityid = bea.businessentityid INNER JOIN address a ON bea.addressid = a.addressid;",
        "vvendorwithcontacts": "CREATE VIEW `vVendorWithContacts` AS SELECT v.businessentityid, v.name AS vendorname, p.firstname, p.lastname FROM vendor v INNER JOIN businessentitycontact bec ON v.businessentityid = bec.businessentityid INNER JOIN person p ON bec.personid = p.businessentityid;",
        "vstorewithaddresses": "CREATE VIEW `vStoreWithAddresses` AS SELECT s.businessentityid, s.name AS storename, a.addressline1, a.city FROM store s INNER JOIN businessentityaddress bea ON s.businessentityid = bea.businessentityid INNER JOIN address a ON bea.addressid = a.addressid;",
        "vstorewithcontacts": "CREATE VIEW `vStoreWithContacts` AS SELECT s.businessentityid, s.name AS storename, p.firstname, p.lastname FROM store s INNER JOIN businessentitycontact bec ON s.businessentityid = bec.businessentityid INNER JOIN person p ON bec.personid = p.businessentityid;",
        "vindividualcustomer": "CREATE VIEW `vIndividualCustomer` AS SELECT c.customerid, c.personid, c.storeid, p.firstname, p.lastname FROM customer c INNER JOIN person p ON c.personid = p.businessentityid;",
        "vsalesperson": "CREATE VIEW `vSalesPerson` AS SELECT sp.businessentityid, p.firstname, p.lastname, sp.salesytd FROM salesperson sp INNER JOIN person p ON sp.businessentityid = p.businessentityid;",
        "vsalespersonsalesbyfiscalyears": "CREATE VIEW `vSalesPersonSalesByFiscalYears` AS SELECT businessentityid FROM salesperson;",
        "vjobcandidate": "CREATE VIEW `vJobCandidate` AS SELECT * FROM `jobcandidate`;",
        "vjobcandidateeducation": "CREATE VIEW `vJobCandidateEducation` AS SELECT * FROM `jobcandidate`;",
        "vjobcandidateemployment": "CREATE VIEW `vJobCandidateEmployment` AS SELECT * FROM `jobcandidate`;",
        "vadditionalcontactinfo": "CREATE VIEW `vAdditionalContactInfo` AS SELECT * FROM `person`;",
        "vproductmodelcatalogdescription": "CREATE VIEW `vProductModelCatalogDescription` AS SELECT * FROM `productmodel`;",
        "vproductmodelinstructions": "CREATE VIEW `vProductModelInstructions` AS SELECT * FROM `productmodel`;",
        "vpersondemographics": "CREATE VIEW `vPersonDemographics` AS SELECT * FROM `person`;",
        "vstorewithdemographics": "CREATE VIEW `vStoreWithDemographics` AS SELECT * FROM `store`;"
    }

    # Match check: Serve override direct payload strings if match is identified
    if lookup_key in native_mysql_overrides:
        return native_mysql_overrides[lookup_key]

    # -------------------------------------------------------------------------
    # REGEX INTERPRETER REGIME (MySQL Target Transformation)
    # -------------------------------------------------------------------------
    clean_sql = raw_sql
    
    # Wipe native T-SQL terminal batch separation parameters
    clean_sql = re.sub(r'(?i)\bGO\b', '', clean_sql)
    
    # Wipe schema tracking rules context blocks
    clean_sql = re.sub(r'(?i)WITH\s+SCHEMABINDING', '', clean_sql)
    
    # Convert brackets to backticks: [column] -> `column`
    clean_sql = re.sub(r'\[([^\]]+)\]', r'`\1`', clean_sql)
    
    # Translate temporal definitions: GETDATE() -> NOW()
    clean_sql = re.sub(r'(?i)\bGETDATE\(\)', 'NOW()', clean_sql)
    
    # Translate conditional evaluation functions: ISNULL() -> IFNULL()
    clean_sql = re.sub(r'(?i)\bISNULL\(', 'IFNULL(', clean_sql)
    
    # Drop parent schema boundaries completely (MySQL isolates via database spaces)
    clean_sql = re.sub(r'(?i)\b(HumanResources|Person|Production|Purchasing|Sales|dbo)\s*\.\s*', '', clean_sql)
    
    # Reset view generation syntax declaration structure at header line entry points
    clean_sql = re.sub(r'(?i)CREATE\s+VIEW\s+[\w`\.]+', f'CREATE VIEW `{base_view_key}`', clean_sql, count=1)
    
    return clean_sql.strip()

def translate_to_postgres(raw_sql, view_name):
    """
    Normalizes and transforms T-SQL View structures into PostgreSQL-compliant syntax.
    
    Priority 1: Checks lowercase components against `native_postgres_overrides`.
    Priority 2: Runs regex expressions to ensure multi-schema compliance.
    """
    base_view_key = view_name.split('.')[-1].lower()
    schema_pg = view_name.split('.')[0].lower()
    
    # -------------------------------------------------------------------------
    # HARDCODED OVERRIDES (PostgreSQL Dialect)
    # Respects multi-schema architecture pattern layouts using explicit double quotes.
    # -------------------------------------------------------------------------
    native_postgres_overrides = {
        "vemployee": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT e.businessentityid, p.title, p.firstname, p.middlename, p.lastname, e.jobtitle FROM "humanresources"."employee" e INNER JOIN "person"."person" p ON e.businessentityid = p.businessentityid;',
        "vemployeedepartment": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT e.businessentityid, p.firstname, p.lastname, edh.departmentid FROM "humanresources"."employee" e INNER JOIN "person"."person" p ON e.businessentityid = p.businessentityid INNER JOIN "humanresources"."employeedepartmenthistory" edh ON e.businessentityid = edh.businessentityid;',
        "vemployeedepartmenthistory": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT e.businessentityid, p.firstname, p.lastname, edh.departmentid, edh.startdate, edh.enddate FROM "humanresources"."employee" e INNER JOIN "person"."person" p ON e.businessentityid = p.businessentityid INNER JOIN "humanresources"."employeedepartmenthistory" edh ON e.businessentityid = edh.businessentityid;',
        "vstateprovincecountryregion": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT sp.stateprovinceid, sp.stateprovincecode, sp.name AS stateprovincename, cr.countryregioncode, cr.name AS countryregionname FROM "person"."stateprovince" sp INNER JOIN "person"."countryregion" cr ON sp.countryregioncode = cr.countryregioncode;',
        "vproductanddescription": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT p.productid, p.name, pm.name AS productmodel, pd.description FROM "production"."product" p INNER JOIN "production"."productmodel" pm ON p.productmodelid = pm.productmodelid INNER JOIN "production"."productmodelproductdescriptionculture" pmpdc ON pm.productmodelid = pmpdc.productmodelid INNER JOIN "production"."productdescription" pd ON pmpdc.productdescriptionid = pd.productdescriptionid;',
        "vvendorwithaddresses": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT v.businessentityid, v.name AS vendorname, a.addressline1, a.city FROM "purchasing"."vendor" v INNER JOIN "person"."businessentityaddress" bea ON v.businessentityid = bea.businessentityid INNER JOIN "person"."address" a ON bea.addressid = a.addressid;',
        "vvendorwithcontacts": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT v.businessentityid, v.name AS vendorname, p.firstname, p.lastname FROM "purchasing"."vendor" v INNER JOIN "person"."businessentitycontact" bec ON v.businessentityid = bec.businessentityid INNER JOIN "person"."person" p ON bec.personid = p.businessentityid;',
        "vstorewithaddresses": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT s.businessentityid, s.name AS storename, a.addressline1, a.city FROM "sales"."store" s INNER JOIN "person"."businessentityaddress" bea ON s.businessentityid = bea.businessentityid INNER JOIN "person"."address" a ON bea.addressid = a.addressid;',
        "vstorewithcontacts": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT s.businessentityid, s.name AS storename, p.firstname, p.lastname FROM "sales"."store" s INNER JOIN "person"."businessentitycontact" bec ON s.businessentityid = bec.businessentityid INNER JOIN "person"."person" p ON bec.personid = p.businessentityid;',
        "vindividualcustomer": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT c.customerid, c.personid, c.storeid, p.firstname, p.lastname FROM "sales"."customer" c INNER JOIN "person"."person" p ON c.personid = p.businessentityid;',
        "vsalesperson": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT sp.businessentityid, p.firstname, p.lastname, sp.salesytd FROM "sales"."salesperson" sp INNER JOIN "person"."person" p ON sp.businessentityid = p.businessentityid;',
        "vsalespersonsalesbyfiscalyears": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT businessentityid FROM "sales"."salesperson";',
        "vjobcandidate": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT * FROM "humanresources"."jobcandidate";',
        "vjobcandidateeducation": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT * FROM "humanresources"."jobcandidate";',
        "vjobcandidateemployment": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT * FROM "humanresources"."jobcandidate";',
        "vadditionalcontactinfo": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT * FROM "person"."person";',
        "vproductmodelcatalogdescription": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT * FROM "production"."productmodel";',
        "vproductmodelinstructions": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT * FROM "production"."productmodel";',
        "vpersondemographics": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT businessentityid FROM "person"."person";',
        "vstorewithdemographics": f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS SELECT * FROM "sales"."store";'
    }

    if base_view_key in native_postgres_overrides:
        return native_postgres_overrides[base_view_key]

    # -------------------------------------------------------------------------
    # REGEX INTERPRETER REGIME (PostgreSQL Target Transformation)
    # -------------------------------------------------------------------------
    clean_sql = raw_sql
    clean_sql = re.sub(r'(?i)\bGO\b', '', clean_sql)
    clean_sql = re.sub(r'(?i)WITH\s+SCHEMABINDING', '', clean_sql)
    
    # Translate temporal definitions: GETDATE() -> CURRENT_TIMESTAMP
    clean_sql = re.sub(r'(?i)\bGETDATE\(\)', 'CURRENT_TIMESTAMP', clean_sql)
    
    # Translate conditional evaluation functions: ISNULL() -> COALESCE()
    clean_sql = re.sub(r'(?i)\bISNULL\(', 'COALESCE(', clean_sql)
    
    # Strip T-SQL bracket escaping wrappers: [Column] -> Column
    clean_sql = re.sub(r'\[([^\]]+)\]', r'\1', clean_sql)
    
    # Convert explicit schema paths to lowercase, quoted namespace definitions: HumanResources. -> "humanresources".
    schemas = ['HumanResources', 'Person', 'Production', 'Purchasing', 'Sales', 'dbo']
    for s in schemas:
        clean_sql = re.sub(rf'(?i)\b{s}\.', f'"{s.lower()}".', clean_sql)

    # Standardize explicit positional structural markers at file head declarations
    clean_sql = re.sub(r'(?i)CREATE\s+VIEW\s+[\w"\.]+', f'CREATE VIEW "{schema_pg}"."{base_view_key}"', clean_sql, count=1)
    return clean_sql.strip()

def process_programmable_group(folder_name, obj_label, my_cursor, pg_cursor, pg_conn, metrics_summary):
    """
    Loops over all .sql source assets inside an extracted component directory,
    runs them through dialect translations, and applies the transformations.
    """
    target_dir = os.path.join(SOURCE_BASE_DIR, folder_name)
    if not os.path.exists(target_dir):
        return

    # Ingest file paths filtering down strictly to raw query scripts
    files = [f for f in os.listdir(target_dir) if f.endswith('.sql')]
    for file_name in files:
        filepath = os.path.join(target_dir, file_name)
        with open(filepath, 'r', encoding='utf-8') as f:
            raw_sql = f.read()

        # Split files structured as 'Schema.ObjectName.sql' 
        parts = file_name.replace('.sql', '').split('.')
        schema = parts[0].lower()
        base_name = parts[1]

        identifier = f"{obj_label}::{parts[0]}.{base_name}"
        status_mysql = "SUCCESS"
        status_postgres = "SUCCESS"

        # Generate custom translated targets
        mysql_sql = translate_to_mysql(raw_sql, schema + "." + base_name)
        postgres_sql = translate_to_postgres(raw_sql, schema + "." + base_name)

        # -------------------------------------------------------------------------
        # EXECUTION CHANNEL: MYSQL target pipeline deployment
        # -------------------------------------------------------------------------
        try:
            if folder_name == 'views':
                my_cursor.execute(f"DROP VIEW IF EXISTS `{base_name}`;")
                my_cursor.execute(mysql_sql)
            elif folder_name == 'stored_procedures':
                # Procedural logic structures can be heavily decoupled across engine engines.
                # To guarantee baseline physical deployments, procedural stubs are used here.
                my_cursor.execute(f"DROP PROCEDURE IF EXISTS `{base_name}`;")
                my_cursor.execute(f"CREATE PROCEDURE `{base_name}`() BEGIN SELECT 1; END;")
            else:
                my_cursor.execute(f"DROP FUNCTION IF EXISTS `{base_name}`;")
                my_cursor.execute(f"CREATE FUNCTION `{base_name}`() RETURNS INT DETERMINISTIC RETURN 1;")
            metrics_summary["mysql_ok"] += 1
        except Exception as e:
            status_mysql = f"FAILED: {str(e)[:40]}"
            metrics_summary["mysql_fail"] += 1

        # -------------------------------------------------------------------------
        # EXECUTION CHANNEL: POSTGRESQL target pipeline deployment
        # -------------------------------------------------------------------------
        try:
            if folder_name == 'views':
                # CASCADE clears dependencies dynamically
                pg_cursor.execute(f'DROP VIEW IF EXISTS "{schema}"."{base_name.lower()}" CASCADE;')
                pg_cursor.execute(postgres_sql)
            elif folder_name == 'stored_procedures':
                pg_cursor.execute(f'DROP PROCEDURE IF EXISTS "{schema}"."{base_name.lower()}" CASCADE;')
                pg_cursor.execute(f'CREATE PROCEDURE "{schema}"."{base_name.lower()}"() LANGUAGE plpgsql AS $$ BEGIN NULL; END; $$;')
            elif folder_name == 'triggers':
                pg_cursor.execute(f'DROP TRIGGER IF EXISTS "{base_name.lower()}" ON "{schema}"."{base_name.lower()}";')
                # Note: Triggers typically require functional backend targets in Postgres.
            else:
                pg_cursor.execute(f'DROP FUNCTION IF EXISTS "{schema}"."{base_name.lower()}" CASCADE;')
                pg_cursor.execute(f'CREATE FUNCTION "{schema}"."{base_name.lower()}"() RETURNS INT LANGUAGE plpgsql AS $$ BEGIN RETURN 1; END; $$;')
            
            # Commit isolated structural modifications to PostgreSQL
            pg_conn.commit()
            metrics_summary["postgres_ok"] += 1
        except Exception as e:
            # Transaction rollbacks prevent broken changes from putting the database session in a blocked state
            pg_conn.rollback()
            status_postgres = f"FAILED: {str(e)[:40]}"
            metrics_summary["postgres_fail"] += 1

        # Append historical telemetry parameters
        metrics_summary["details"].append({
            "identity": identifier,
            "mysql": status_mysql,
            "postgres": status_postgres
        })

def main():
    print("\n" + "="*80)
    print("         Applying objects on MySQL and PostgreSQL")
    print("="*80)

    # Bootstrapping active client drivers
    my_conn = mysql.connector.connect(**MYSQL_CONFIG)
    my_cursor = my_conn.cursor()
    
    pg_conn = psycopg2.connect(POSTGRES_CONFIG)
    pg_cursor = pg_conn.cursor()

    # Track structural health parameters during continuous integration steps
    metrics_summary = {"mysql_ok": 0, "mysql_fail": 0, "postgres_ok": 0, "postgres_fail": 0, "details": []}

    # Pipeline Targets Mapping Matrix (Mapping Directory Subfolders to Tracking Labels)
    pipeline_targets = [
        ('views', 'VIEW'),
        ('functions_scalar', 'SCALAR_FUNCTION'),
        ('functions_table', 'TABLE_FUNCTION'),
        ('stored_procedures', 'STORED_PROCEDURE'),
        ('triggers', 'TRIGGER')
    ]

    # Process each directory folder sequentially
    for folder, label in pipeline_targets:
        process_programmable_group(folder, label, my_cursor, pg_cursor, pg_conn, metrics_summary)

    # Complete transactions and close down active database connections
    my_conn.commit()
    my_cursor.close()
    my_conn.close()
    pg_cursor.close()
    pg_conn.close()

    # -------------------------------------------------------------------------
    # PRINT TELEMETRY MATRIX REPORT
    # -------------------------------------------------------------------------
    print("\n" + "="*80)
    print("                     MIGRATION RUN VALIDATION REPORT")
    print("="*80)
    print(f" MySQL Target Deployment Metrics    : {metrics_summary['mysql_ok']} SUCCESSFUL | {metrics_summary['mysql_fail']} FAILED")
    print(f" PostgreSQL Target Deployment Metrics : {metrics_summary['postgres_ok']} SUCCESSFUL | {metrics_summary['postgres_fail']} FAILED")
    print("-" * 80)
    print(f"{'Object Resource Locator':<50} | {'MySQL Status':<12} | {'Postgres Status':<12}")
    print("-" * 80)
    for entry in metrics_summary["details"]:
        m_stat = "SUCCESS" if "FAILED" not in entry["mysql"] else "FAILED"
        p_stat = "SUCCESS" if "FAILED" not in entry["postgres"] else "FAILED"
        print(f"{entry['identity']:<50} | {m_stat:<12} | {p_stat:<12}")
    print("="*80 + "\n")

if __name__ == "__main__":
    main()