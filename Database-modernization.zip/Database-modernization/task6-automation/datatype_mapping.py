# datatype_mapping.py

SQLSERVER_TO_SAFE_TYPE = {
    # strings
    "nvarchar": "TEXT",
    "varchar": "TEXT",
    "nchar": "TEXT",
    "char": "TEXT",
    "text": "TEXT",
    "ntext": "TEXT",

    # numbers
    "int": "INT",
    "bigint": "BIGINT",
    "smallint": "INT",
    "tinyint": "INT",
    "bit": "BOOLEAN",
    "decimal": "DOUBLE",
    "numeric": "DOUBLE",
    "float": "DOUBLE",
    "real": "DOUBLE",

    # datetime
    "date": "DATE",
    "datetime": "DATETIME",
    "datetime2": "DATETIME",

    # binary
    "varbinary": "BLOB",
    "binary": "BLOB",
    "image": "BLOB",

    # FIX CRITICAL FAILURES (-151 ERROR ROOT CAUSE)
    "geography": "TEXT",
    "geometry": "TEXT",
    "hierarchyid": "TEXT",
    "sql_variant": "TEXT",
    "xml": "TEXT",
}