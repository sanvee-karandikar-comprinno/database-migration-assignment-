"""
 Cross-Database Synchronization Pipeline
========================================================================
Context:
Migrating a Microsoft SQL Server production database (AdventureWorks) simultaneously 
into two different target open-source engines: MySQL and PostgreSQL.

Key Architectural Challenges Solved:
1. Heterogeneous Data Type Mapping: Normalizes complex MSSQL types (XML, spatial data, 
   and binary streams) into formats natively accepted by MySQL and PostgreSQL.
2. XML Double-Encoding Workaround: Implements a double-cast operation 
   (NVARCHAR -> VARCHAR -> Native string stream) uniquely targeting the 
   `HumanResources.JobCandidate` table to handle nested schemas without parser truncation.
3. Decoupled Schema Topologies: Maps multi-schema relational tables into flat name 
   spaces for MySQL while preserving isolated namespaces (schemas) inside PostgreSQL.
4. Data Integrity Telemetry: Aggregates atomic row counts post-load across all three 
   active engines to output a definitive validation synchronization report matrix.
"""

import os
import re
import pyodbc
import mysql.connector
import psycopg2
import time
import logging
import sys

# ===========================================================================
# GLOBAL PIPELINE CONFIGURATION
# ===========================================================================
MYSQL_DB = "adventureworks_mysql"
PG_DB = "adventureworks_pg"

# Standardizing runtime log outputs to redirect to standard stdout streams
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)

# Strategic Mapping Rules: Converts proprietary Microsoft spatial and variant 
# object fields into clean SQL string streams via text casting expressions.
UNSAFE_TYPES = {
    "geography": "OBJECT_TO_STRING",
    "geometry": "OBJECT_TO_STRING",
    "hierarchyid": "OBJECT_TO_STRING",
    "sql_variant": "OBJECT_TO_STRING"
}

# ===========================================================================
# DATABASE DRIVER ATTACHMENT POOL
# ===========================================================================
def connect_mssql():
    """Establishes an active local pipeline channel into the MSSQL Source."""
    return pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};"
        "SERVER=localhost;"
        "DATABASE=AdventureWorks2025;"
        "Trusted_Connection=yes;"
    )

def connect_mysql(database=None):
    """Establishes an active local pipeline channel into the MySQL Destination."""
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="1234",
        database=database,
        charset="utf8mb4",
        use_unicode=True
    )

def connect_postgres(database="postgres"):
    """Establishes an active local pipeline channel into the PostgreSQL Destination."""
    return psycopg2.connect(
        host="localhost",
        port=5433,
        user="postgres",
        password="1234",
        dbname=database
    )

# ===========================================================================
# COMPONENT INITIALIZATION (BOOTSTRAPPER)
# ===========================================================================
def init_mysql():
    """Ensures the destination MySQL schema room is instantiated."""
    conn = connect_mysql()
    cur = conn.cursor()
    cur.execute(f"CREATE DATABASE IF NOT EXISTS {MYSQL_DB}")
    conn.commit()
    conn.close()

def init_postgres():
    """Ensures the target PostgreSQL database context exists physically on disk."""
    conn = connect_postgres("postgres")
    conn.autocommit = True  # Required to run architectural 'CREATE DATABASE' commands
    cur = conn.cursor()
    cur.execute(f"SELECT 1 FROM pg_database WHERE datname='{PG_DB}'")
    if not cur.fetchone():
        cur.execute(f"CREATE DATABASE {PG_DB}")
    conn.close()

# ===========================================================================
# CORE SCHEMA DATA DISCOVERY
# ===========================================================================
def fetch_tables(cur):
    """
    Scans the source system catalog to isolate valid application entities,
    filtering out internal engine tracking systems (sys, INFORMATION_SCHEMA).
    """
    cur.execute("""
        SELECT TABLE_SCHEMA, TABLE_NAME
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_TYPE='BASE TABLE'
    """)
    tables = cur.fetchall()
    return [(s, t) for s, t in tables if s not in ["sys", "INFORMATION_SCHEMA"]]

# ===========================================================================
# SYSTEM EXTRACTION LAYER & DATA-TYPE CONVERSION PIPELINE
# ===========================================================================
def fetch_data_and_schema(ms_cur, schema, table):
    """
    Extracts raw table data while dynamically adjusting structural column 
    expressions to eliminate syntax incompatibilities before data wire transfer.
    """
    # 1. Inspect low-level metadata column positions
    col_query = f"""
        SELECT COLUMN_NAME, DATA_TYPE
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA='{schema}' AND TABLE_NAME='{table}'
        ORDER BY ORDINAL_POSITION
    """
    ms_cur.execute(col_query)
    col_definitions = ms_cur.fetchall()
    cols = [row[0] for row in col_definitions]

    select_parts = []
    
    # Target Isolation: Identify if the processor is running against the 
    # highly specialized, deeply nested structural JobCandidate table.
    is_job_candidate = f"{schema}.{table}".lower() == "humanresources.jobcandidate"

    # 2. Iterate through columns to generate tailored SQL query selection components
    for col, dtype in col_definitions:
        dt_lower = dtype.lower()
        
        if dt_lower == "xml":
            if is_job_candidate:
                # SPECIAL HANDLING: Bypasses encoding and truncation issues on complex XML
                # by performing a safe two-tiered textual conversion macro.
                select_parts.append(f"CONVERT(VARCHAR(MAX), CONVERT(NVARCHAR(MAX), [{col}])) AS [{col}]")
            else:
                # Standard conversion expression applied across the remaining application views/tables
                select_parts.append(f"CAST([{col}] AS VARCHAR(MAX)) AS [{col}]")
                
        elif dt_lower in UNSAFE_TYPES:
            # Spatial datatypes are transformed to standard strings using built-in Object methods
            strategy = UNSAFE_TYPES[dt_lower]
            if strategy == "OBJECT_TO_STRING":
                select_parts.append(f"CAST([{col}].ToString() AS VARCHAR(MAX)) AS [{col}]")
                
        elif dt_lower in ['varbinary', 'image', 'binary']:
            # Converts raw binary arrays to hexadecimal string representation streams (Style flag: 2)
            select_parts.append(f"CONVERT(VARCHAR(MAX), [{col}], 2) AS [{col}]")
        else:
            # Safe default primitive types are pulled down directly without alterations
            select_parts.append(f"[{col}]")

    # Construct and run the translation query string against the source database
    query = f"SELECT {', '.join(select_parts)} FROM [{schema}].[{table}]"
    ms_cur.execute(query)
    raw_rows = ms_cur.fetchall()
    
    return cols, col_definitions, [tuple(r) for r in raw_rows]

# ===========================================================================
# TARGET PIPELINE CHANNELS: MYSQL ENGINES
# ===========================================================================
def create_mysql_table(conn, table, cols):
    """
    Creates flat, non-relational storage matrices inside the target MySQL pool,
    defaulting columns to LONGTEXT to dynamically accept large inputs.
    """
    cur = conn.cursor()
    cur.execute(f"CREATE TABLE IF NOT EXISTS `{table}` (" +
                ", ".join([f"`{c}` LONGTEXT" for c in cols]) + ")")
    conn.commit()
    cur.close()

def run_mysql_load(conn, table, cols, col_definitions, rows):
    """
    Loads normalized tabular record matrices into target MySQL engine contexts.
    """
    cur = conn.cursor()
    try:
        # Disable foreign key evaluation steps to facilitate clean bulk record injection
        cur.execute("SET FOREIGN_KEY_CHECKS = 0;")
        # Maximize connection buffer packets to comfortably handle massive object uploads
        cur.execute("SET GLOBAL max_allowed_packet = 1073741824;") 
        
        # Override Target Modifications: Explicitly transition storage parameters 
        # to LONGBLOB for known structural binary/document asset fields.
        if table.lower() == "document":
            cur.execute("ALTER TABLE `Document` MODIFY COLUMN `Document` LONGBLOB NULL;")
        elif table.lower() == "productphoto":
            cur.execute("ALTER TABLE `ProductPhoto` MODIFY COLUMN `ThumbNailPhoto` LONGBLOB NULL;")
            cur.execute("ALTER TABLE `ProductPhoto` MODIFY COLUMN `LargePhoto` LONGBLOB NULL;")
            
        cur.execute(f"TRUNCATE TABLE `{table}`")
        col_str = ",".join([f"`{c}`" for c in cols])
        
        # Iterative transactional record engine loader loop
        for row in rows:
            query_placeholders = []
            param_values = []
            
            for idx, val in enumerate(row):
                dt = col_definitions[idx][1].lower()
                if val is None:
                    query_placeholders.append("NULL")
                elif dt in ['varbinary', 'image', 'binary']:
                    # Reconstructs valid inline raw Hex strings (0x...) for binary storage
                    query_placeholders.append(f"0x{bytes(val).hex()}" if isinstance(val, (bytes, bytearray)) else f"0x{str(val)}")
                else:
                    query_placeholders.append("%s")
                    param_values.append(val)
                    
            insert_query = f"INSERT INTO `{table}` ({col_str}) VALUES ({','.join(query_placeholders)})"
            cur.execute(insert_query, tuple(param_values))
            
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        # Re-enable constraint parameters globally on exit
        cur.execute("SET FOREIGN_KEY_CHECKS = 1;")
        cur.close()

# ===========================================================================
# TARGET PIPELINE CHANNELS: POSTGRESQL ENGINES
# ===========================================================================
def run_postgres_load(conn, schema, table, cols, col_definitions, rows):
    """
    Maps and converts types to deploy clean table architectures inside 
    multi-schema PostgreSQL environments before streaming records.
    """
    cur = conn.cursor()
    try:
        pg_schema = schema.lower()
        pg_table = table.lower()
        
        cur.execute(f"CREATE SCHEMA IF NOT EXISTS {pg_schema};")
        
        # Complete T-SQL to PostgreSQL Type Translation Matrix Configuration
        type_map = {
            'int': 'INT', 'bigint': 'BIGINT', 'smallint': 'SMALLINT', 'tinyint': 'SMALLINT',
            'bit': 'BOOLEAN', 'varchar': 'TEXT', 'nvarchar': 'TEXT', 'char': 'TEXT', 'nchar': 'TEXT',
            'text': 'TEXT', 'ntext': 'TEXT', 'datetime': 'TIMESTAMP', 'smalldatetime': 'TIMESTAMP',
            'date': 'DATE', 'time': 'TIME', 'uniqueidentifier': 'UUID', 'money': 'NUMERIC',
            'smallmoney': 'NUMERIC', 'decimal': 'NUMERIC', 'numeric': 'NUMERIC',
            'float': 'DOUBLE PRECISION', 'real': 'REAL', 'varbinary': 'BYTEA', 'binary': 'BYTEA',
            'image': 'BYTEA', 'xml': 'XML', 'hierarchyid': 'TEXT', 'geography': 'TEXT', 'geometry': 'TEXT'
        }
        
        fields = []
        for c, dt in col_definitions:
            pg_type = type_map.get(dt.lower(), 'TEXT')
            fields.append(f'"{c}" {pg_type}')
            
        cur.execute(f'CREATE TABLE IF NOT EXISTS "{pg_schema}"."{pg_table}" ({", ".join(fields)});')
        # Cascade truncations ensure any dependent table structures clear cleanly
        cur.execute(f'TRUNCATE TABLE "{pg_schema}"."{pg_table}" RESTART IDENTITY CASCADE;')
        conn.commit()

        col_str = ",".join([f'"{c}"' for c in cols])
        placeholders = ",".join(["%s"] * len(cols))
        insert_query = f'INSERT INTO "{pg_schema}"."{pg_table}" ({col_str}) VALUES ({placeholders})'

        # Prepares values for the batch load operation (executemany)
        pg_prepared_rows = []
        for r in rows:
            row_items = []
            for item, (c, dt) in zip(r, col_definitions):
                dt_lower = dt.lower()
                if dt_lower in ['varbinary', 'image', 'binary'] and item is not None:
                    # Enforces binary mapping patterns via psycopg2 container proxies
                    raw_bytes = bytes.fromhex(item) if isinstance(item, str) else bytes(item)
                    row_items.append(psycopg2.Binary(raw_bytes))
                else:
                    row_items.append(item)
            pg_prepared_rows.append(tuple(row_items))

        # Perform efficient high-performance block array insertions
        cur.executemany(insert_query, pg_prepared_rows)
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        cur.close()

# ===========================================================================
# TELEMETRY RECONCILIATION VERIFICATION LAYER
# ===========================================================================
def get_count_mssql(cur, schema, table):
    """Fetches atomic total record count parameters from the MSSQL instance."""
    cur.execute(f"SELECT COUNT(*) FROM [{schema}].[{table}]")
    return cur.fetchone()[0]

def get_count_mysql(conn, table):
    """Fetches atomic total record count parameters from the MySQL instance."""
    cur = conn.cursor()
    cur.execute(f"SELECT COUNT(*) FROM `{table}`")
    res = cur.fetchone()[0]
    cur.close()
    return res

def get_count_pg(conn, schema, table):
    """Fetches atomic total record count parameters from the PostgreSQL instance."""
    cur = conn.cursor()
    cur.execute(f'SELECT COUNT(*) FROM "{schema.lower()}"."{table.lower()}"')
    res = cur.fetchone()[0]
    cur.close()
    return res

# ===========================================================================
# TRANSIENT NETWORK FAULT MITIGATION WRAPPER (RETRY PATTERN)
# ===========================================================================
def retry(fn, name, retries=3):
    """
    Executes an operations callback block, intercepting network or deadlock errors 
    and retrying up to a configured threshold before flagging a failure.
    """
    for i in range(retries):
        try:
            return fn()
        except Exception as e:
            logging.error(f"Attempt {i+1} failed for {name}: {e}")
            time.sleep(1)
    raise Exception(f"FAILED AFTER RETRIES: {name}")

# ===========================================================================
# CORE COORDINATION PIPELINE ENGINE
# ===========================================================================
def migrate():
    print("=" * 75)
    print("       STARTING UNIFIED ENTERPRISE DATA MIGRATION PIPELINE")
    print("=" * 75)

    # 1. Spin up schemas and infrastructure rooms
    init_mysql()
    init_postgres()

    # 2. Establish connections to all active processing drivers
    mssql = connect_mssql()
    mysql_conn = connect_mysql(MYSQL_DB)
    pg_conn = connect_postgres(PG_DB)

    m_cur = mssql.cursor()
    tables = fetch_tables(m_cur)

    print(f"\nTotal discovered source tables: {len(tables)}\n")
    
    # Storage cache for global report generation matrix parameters
    report_matrix = []

    # 3. Main migration loop processing discovered target data arrays sequentially
    for i, (schema, table) in enumerate(tables, 1):
        full_name = f"{schema}.{table}"
        print("-" * 75)
        print(f"[{i}/{len(tables)}] PROCESSING TARGET: {full_name}")
        print("-" * 75)

        table_stats = {
            "name": full_name, "mssql": "-", "mysql": "-", "postgres": "-", "status": "SKIPPED"
        }

        try:
            # --- STAGE 1: EXTRACTION PHASE ---
            cols, col_definitions, rows = retry(
                lambda: fetch_data_and_schema(m_cur, schema, table),
                f"Extracting {full_name}"
            )
            mssql_count = get_count_mssql(m_cur, schema, table)
            table_stats["mssql"] = mssql_count

            # --- STAGE 2: MYSQL INGESTION PHASE ---
            create_mysql_table(mysql_conn, table, cols)
            retry(
                lambda: run_mysql_load(mysql_conn, table, cols, col_definitions, rows),
                f"MySQL Load for {table}"
            )
            mysql_count = get_count_mysql(mysql_conn, table)
            table_stats["mysql"] = mysql_count

            # --- STAGE 3: POSTGRESQL INGESTION PHASE ---
            retry(
                lambda: run_postgres_load(pg_conn, schema, table, cols, col_definitions, rows),
                f"Postgres Load for {full_name}"
            )
            pg_count = get_count_pg(pg_conn, schema, table)
            table_stats["postgres"] = pg_count

            print(f"Metrics validation -> MSSQL: {mssql_count} | MYSQL: {mysql_count} | POSTGRES: {pg_count}")

            # --- STAGE 4: DATA AUDITING & RECONCILIATION ---
            if mssql_count != mysql_count or mssql_count != pg_count:
                logging.warning(f"CRITICAL ROW COUNT BOUNDARY MISMATCH DETECTED: {full_name}")
                table_stats["status"] = "MISMATCH"
            else:
                print(f"Verification Success: {full_name} is synchronized.")
                table_stats["status"] = "SUCCESS"

        except Exception as e:
            logging.error(f"FATAL PIPELINE CRASH ON TABLE {full_name}: {e}")
            # Ensure transactions are rolled back to keep target database pools clean
            mysql_conn.rollback()
            pg_conn.rollback()
            table_stats["status"] = "FAILED"

        report_matrix.append(table_stats)

    # 4. Release execution pipeline worker resources
    m_cur.close()
    mssql.close()
    mysql_conn.close()
    pg_conn.close()

    # ===========================================================================
    # TELEMETRY RECONCILIATION MANIFEST REPORT GENERATOR
    # ===========================================================================
    print("\n" + "=" * 90)
    print("                      GLOBAL ENGINE VALIDATION TELEMETRY REPORT")
    print("=" * 90)
    print(f"{'TARGET DATATABLE OBJECT':<45} | {'MSSQL':<8} | {'MYSQL':<8} | {'POSTGRES':<8} | {'STATUS':<10}")
    print("-" * 90)
    
    success_count = 0
    for entry in report_matrix:
        print(f"{entry['name']:<45} | {entry['mssql']:<8} | {entry['mysql']:<8} | {entry['postgres']:<8} | {entry['status']:<10}")
        if entry['status'] == "SUCCESS":
            success_count += 1
            
    print("=" * 90)
    print(f"SUMMARY: {success_count}/{len(report_matrix)} Tables Fully Synchronized to All Environments.")
    print("=" * 90 + "\n")

if __name__ == "__main__":
    migrate()