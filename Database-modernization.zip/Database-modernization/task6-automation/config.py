# config.py

MSSQL_CONFIG = {
    "server": r"DESKTOP-GAFOR5H\SQLEXPRESS",  
    "database": "AdventureWorks2025",
    "trusted_connection": "yes",
    "driver": "ODBC Driver 17 for SQL Server"
}

MYSQL_CONFIG = {
    "host": "localhost",
    "port": 3306,          
    "user": "root",
    "password": "1234",
    "database": "adventureworks_mysql"
}

POSTGRES_CONFIG = {
    "host": "localhost",
    "port": 5433,          
    "user": "postgres",
    "password": "1234",
    "database": "adventureworks_pg"
}