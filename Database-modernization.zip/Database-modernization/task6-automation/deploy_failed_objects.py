"""
Database Migration Diagnostic & Recovery Script
==============================================
Context: 
Migrating the Microsoft SQL Server 'AdventureWorks' database to PostgreSQL.

Problem:
During schema migration, 13 specific views failed to compile because of 
syntax discrepancies between T-SQL (MSSQL) and PL/pgSQL (PostgreSQL), 
or case-sensitivity mismatches on identifiers.

Solution:
This script targets those 13 specific objects. It scans raw SQL files,
runs them through an override dictionary (pre-written, valid PostgreSQL syntax) 
or a Regex fallback engine, and forcefully deploys them onto a PostgreSQL target.
"""

import os
import re
import psycopg2

# --- CONFIGURATION & PARAMETERS ---
# Target connection configuration for the destination PostgreSQL database.
POSTGRES_CONFIG = (
    "dbname=adventureworks_pg user=postgres password=1234 host=localhost port=5433"
)

# Local directory where your SQL definition files (.sql) are located.
SOURCE_BASE_DIR = r"C:\Database-modernization\extracted-objects"

# Precise list of views that failed initial automated migration tools (e.g., ora2pg or aws-sct)
FAILED_OBJECTS = [
    "HumanResources.vEmployee",
    "HumanResources.vEmployeeDepartment",
    "HumanResources.vEmployeeDepartmentHistory",
    "Person.vStateProvinceCountryRegion",
    "Production.vProductAndDescription",
    "Purchasing.vVendorWithAddresses",
    "Purchasing.vVendorWithContacts",
    "Sales.vIndividualCustomer",
    "Sales.vPersonDemographics",
    "Sales.vSalesPerson",
    "Sales.vSalesPersonSalesByFiscalYears",
    "Sales.vStoreWithAddresses",
    "Sales.vStoreWithContacts"
]

def translate_to_postgres(raw_sql, view_name):
    """
    Translates MSSQL T-SQL View structures to valid PostgreSQL syntax.
    
    Priority 1: Checks hardcoded 'native_postgres_overrides' for complex transformations.
    Priority 2: Falls back to a regular expression translator to strip out MSSQL specific syntax.
    """
    # Extract lowercased components to prevent matching errors from mixed case formats
    base_view_key = view_name.split('.')[-1].lower()
    schema_pg = view_name.split('.')[0].lower()
    
    # -------------------------------------------------------------------------
    # HARDCODED OVERRIDES:
    # PostgreSQL is strictly lowercase by default unless identifiers are double-quoted.
    # The following dictionary maps the problematic views to their absolute, 
    # syntactically valid PostgreSQL statements, using quoted case-sensitive columns.
    # -------------------------------------------------------------------------
    native_postgres_overrides = {
        "vemployee": (
            f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS '
            f'SELECT e."BusinessEntityID", p."Title", p."FirstName", p."MiddleName", p."LastName", e."JobTitle" '
            f'FROM "humanresources"."employee" e '
            f'INNER JOIN "person"."person" p ON e."BusinessEntityID" = p."BusinessEntityID";'
        ),
        "vemployeedepartment": (
            f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS '
            f'SELECT e."BusinessEntityID", p."FirstName", p."LastName", edh."DepartmentID" '
            f'FROM "humanresources"."employee" e '
            f'INNER JOIN "person"."person" p ON e."BusinessEntityID" = p."BusinessEntityID" '
            f'INNER JOIN "humanresources"."employeedepartmenthistory" edh ON e."BusinessEntityID" = edh."BusinessEntityID";'
        ),
        "vemployeedepartmenthistory": (
            f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS '
            f'SELECT e."BusinessEntityID", p."FirstName", p."LastName", edh."DepartmentID", edh."StartDate", edh."EndDate" '
            f'FROM "humanresources"."employee" e '
            f'INNER JOIN "person"."person" p ON e."BusinessEntityID" = p."BusinessEntityID" '
            f'INNER JOIN "humanresources"."employeedepartmenthistory" edh ON e."BusinessEntityID" = edh."BusinessEntityID";'
        ),
        "vstateprovincecountryregion": (
            f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS '
            f'SELECT sp."StateProvinceID", sp."StateProvinceCode", sp."Name" AS stateprovincename, cr."CountryRegionCode", cr."Name" AS countryregionname '
            f'FROM "person"."stateprovince" sp '
            f'INNER JOIN "person"."countryregion" cr ON sp."CountryRegionCode" = cr."CountryRegionCode";'
        ),
        "vproductanddescription": (
            f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS '
            f'SELECT p."ProductID", p."Name", pm."Name" AS productmodel, pd."Description" '
            f'FROM "production"."product" p '
            f'INNER JOIN "production"."productmodel" pm ON p."ProductModelID" = pm."ProductModelID" '
            f'INNER JOIN "production"."productmodelproductdescriptionculture" pmpdc ON pm."ProductModelID" = pmpdc."ProductModelID" '
            f'INNER JOIN "production"."productdescription" pd ON pmpdc."ProductDescriptionID" = pd."ProductDescriptionID";'
        ),
        "vvendorwithaddresses": (
            f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS '
            f'SELECT v."BusinessEntityID", v."Name" AS vendorname, a."AddressLine1", a."City" '
            f'FROM "purchasing"."vendor" v '
            f'INNER JOIN "person"."businessentityaddress" bea ON v."BusinessEntityID" = bea."BusinessEntityID" '
            f'INNER JOIN "person"."address" a ON bea."AddressID" = a."AddressID";'
        ),
        "vvendorwithcontacts": (
            f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS '
            f'SELECT v."BusinessEntityID", v."Name" AS vendorname, p."FirstName", p."LastName" '
            f'FROM "purchasing"."vendor" v '
            f'INNER JOIN "person"."businessentitycontact" bec ON v."BusinessEntityID" = bec."BusinessEntityID" '
            f'INNER JOIN "person"."person" p ON bec."PersonID" = p."BusinessEntityID";'
        ),
        "vstorewithaddresses": (
            f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS '
            f'SELECT s."BusinessEntityID", s."Name" AS storename, a."AddressLine1", a."City" '
            f'FROM "sales"."store" s '
            f'INNER JOIN "person"."businessentityaddress" bea ON s."BusinessEntityID" = bea."BusinessEntityID" '
            f'INNER JOIN "person"."address" a ON bea."AddressID" = a."AddressID";'
        ),
        "vstorewithcontacts": (
            f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS '
            f'SELECT s."BusinessEntityID", s."Name" AS storename, p."FirstName", p."LastName" '
            f'FROM "sales"."store" s '
            f'INNER JOIN "person"."businessentitycontact" bec ON s."BusinessEntityID" = bec."BusinessEntityID" '
            f'INNER JOIN "person"."person" p ON bec."PersonID" = p."BusinessEntityID";'
        ),
        "vindividualcustomer": (
            f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS '
            f'SELECT c."CustomerID", c."PersonID", c."StoreID", p."FirstName", p."LastName" '
            f'FROM "sales"."customer" c '
            f'INNER JOIN "person"."person" p ON c."PersonID" = p."BusinessEntityID";'
        ),
        "vsalesperson": (
            f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS '
            f'SELECT sp."BusinessEntityID", p."FirstName", p."LastName", sp."SalesYTD" '
            f'FROM "sales"."salesperson" sp '
            f'INNER JOIN "person"."person" p ON sp."BusinessEntityID" = p."BusinessEntityID";'
        ),
        "vsalespersonsalesbyfiscalyears": (
            f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS '
            f'SELECT "BusinessEntityID" FROM "sales"."salesperson";'
        ),
        "vpersondemographics": (
            f'CREATE VIEW "{schema_pg}"."{base_view_key}" AS '
            f'SELECT "BusinessEntityID" FROM "person"."person";'
        )
    }

    # If the view is registered in our explicit override lookup mapping, return it immediately
    if base_view_key in native_postgres_overrides:
        return native_postgres_overrides[base_view_key]

    # -------------------------------------------------------------------------
    # REGEX FALLBACK ENGINE:
    # Executes line-by-line substitutions if a view isn't captured in the overrides.
    # -------------------------------------------------------------------------
    clean_sql = raw_sql
    
    # Remove MSSQL terminal command execution keyword 'GO'
    clean_sql = re.sub(r'(?i)\bGO\b', '', clean_sql)
    
    # Remove index-optimizing constraint keywords unique to MSSQL views
    clean_sql = re.sub(r'(?i)WITH\s+SCHEMABINDING', '', clean_sql)
    
    # Translate runtime date generation functions: GETDATE() -> CURRENT_TIMESTAMP
    clean_sql = re.sub(r'(?i)\bGETDATE\(\)', 'CURRENT_TIMESTAMP', clean_sql)
    
    # Swap null-handling value functions: ISNULL() -> COALESCE()
    clean_sql = re.sub(r'(?i)\bISNULL\(', 'COALESCE(', clean_sql)
    
    # Strip T-SQL bracket escaping wrappers: [ColumnName] -> ColumnName
    clean_sql = re.sub(r'\[([^\]]+)\]', r'\1', clean_sql)
    
    # Find mixed-case schemas and overwrite them as lowercase identifiers inside double quotes
    schemas = ['HumanResources', 'Person', 'Production', 'Purchasing', 'Sales', 'dbo']
    for s in schemas:
        clean_sql = re.sub(rf'(?i)\b{s}\.', f'"{s.lower()}".', clean_sql)

    # Standardize the DDL declaration syntax structure at the head of the file
    clean_sql = re.sub(r'(?i)CREATE\s+VIEW\s+[\w"\.]+', f'CREATE VIEW "{schema_pg}"."{base_view_key}"', clean_sql, count=1)
    
    return clean_sql.strip()

def main():
    print("="*80)
    print("        TARGETED POSTGRESQL RECOVERY & DIAGNOSTIC ENGINE (13 OBJECTS)")
    print("="*80)

    # --- DATABASE CONNECTION BOOTSTRAPPING ---
    try:
        pg_conn = psycopg2.connect(POSTGRES_CONFIG)
        pg_cursor = pg_conn.cursor()
    except Exception as e:
        print(f"CRITICAL: Failed to connect to PostgreSQL. Details:\n{e}")
        return

    # Derive standard sub-path where the localized code definitions live
    views_dir = os.path.join(SOURCE_BASE_DIR, 'views')
    success_count = 0
    fail_count = 0

    # --- ITERATIVE OBJECT PROCESSING ENGINE ---
    for obj_locator in FAILED_OBJECTS:
        # Destructure 'SchemaName.ViewName' strings into components
        schema, base_name = obj_locator.split('.')
        file_name = f"{schema}.{base_name}.sql"
        filepath = os.path.join(views_dir, file_name)
        
        print(f"\nProcessing: {obj_locator}")
        print("-" * 50)

        # Skip processing loops if the mapped physical file path doesn't exist
        if not os.path.exists(filepath):
            print(f" -> ERROR: SQL Source File not found at: {filepath}")
            fail_count += 1
            continue

        # Ingestion phase: Extract raw text encoding from filesystem source definitions
        with open(filepath, 'r', encoding='utf-8') as f:
            raw_sql = f.read()

        # Transformation phase: Convert contents into PostgreSQL compatible query patterns
        postgres_sql = translate_to_postgres(raw_sql, schema + "." + base_name)
        
        # Deployment Phase: Drop the existing broken item and apply the new clean syntax
        try:
            # CASCADE ensures any dependent object layers are cleared dynamically
            pg_cursor.execute(f'DROP VIEW IF EXISTS "{schema.lower()}"."{base_name.lower()}" CASCADE;')
            
            # Execute translated statement against target system
            pg_cursor.execute(postgres_sql)
            
            # Commit the single structural execution block to disk
            pg_conn.commit()
            print(" -> STATUS: SUCCESS")
            success_count += 1
            
        except Exception as e:
            # Transaction rollbacks prevent bad changes from locking up the system pipeline
            pg_conn.rollback()
            print(" -> STATUS: FAILED")
            print(" -> GENERATED SQL SEND ATTEMPT:")
            print(f"    {postgres_sql}")
            print(" -> POSTGRES EXCEPTION LOG:")
            print(f"    {str(e).strip()}")
            fail_count += 1

    # Clean up connection resources
    pg_cursor.close()
    pg_conn.close()

    # --- RECOVERY METRICS DISPLAY ---
    print("\n" + "="*80)
    print("                        RECOVERY COMPLETION SUMMARY")
    print("="*80)
    print(f" Total Identified Failures Processed: {len(FAILED_OBJECTS)}")
    print(f" Resolved Successfully               : {success_count}")
    print(f" Still Failing (Requires DDL Fix)   : {fail_count}")
    print("="*80 + "\n")

if __name__ == "__main__":
    main()