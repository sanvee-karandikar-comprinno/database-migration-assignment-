"""
Microsoft SQL Server Programmable Object Extraction Engine
=========================================================
Context:
The primary ingestion stage of a database modernization pipeline. 

Problem:
Before migrating an MSSQL database (like AdventureWorks) to open-source targets, 
you must extract the underlying code of views, stored procedures, functions, 
and triggers which are buried inside system catalogs.

Solution:
This script queries the MSSQL data dictionary (`INFORMATION_SCHEMA` and `sys` metadata), 
extracts the raw SQL DDL code for every programmable object inside specified production 
schemas, categorizes them by object type, and saves them into a structured local directory.
"""

import os
import pyodbc

# --- DATABASE CONNECTION & TARGET CONFIGURATION ---
# Connection string using the Windows ODBC driver to authenticate via Trusted Connection (Windows Auth)
SQL_SERVER_CONFIG = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=localhost\\SQLEXPRESS;"  
    "DATABASE=AdventureWorks2019;"   
    "Trusted_Connection=yes;"
)

# Destination directory where structural .sql files will be dumped
OUTPUT_BASE_DIR = r"C:\Database-modernization\extracted-objects"

def create_folders():
    """
    Scans the destination environment and creates subdirectories for each 
    distinct programmable object category if they don't already exist.
    """
    folders = ['views', 'stored_procedures', 'functions_scalar', 'functions_table', 'triggers']
    for f in folders:
        # exist_ok=True prevents the script from crashing if directories are already present
        os.makedirs(os.path.join(OUTPUT_BASE_DIR, f), exist_ok=True)

def main():
    print("=" * 80)
    print("         MSSQL PROGRAMMABLE OBJECT EXTRACTION ENGINE (V3)")
    print("=" * 80)

    # --- ATTACH DATABASE DRIVERS ---
    try:
        conn = pyodbc.connect(SQL_SERVER_CONFIG)
        cursor = conn.cursor()
        print("[+] Successfully attached using Windows Authentication.")
    except Exception as e:
        print(f"[-] Connection failed: {e}")
        return

    # Initialize the local directory architecture
    create_folders()
    
    # Internal counter map to provide pipeline telemetry at execution wrap-up
    extracted_counts = {
        'views': 0, 
        'stored_procedures': 0, 
        'functions_scalar': 0, 
        'functions_table': 0, 
        'triggers': 0
    }

    # -------------------------------------------------------------------------
    # PHASE 1: EXTRACTION OF VIEWS (Via INFORMATION_SCHEMA.VIEWS)
    # -------------------------------------------------------------------------
    print("[*] Harvesting View layer definitions from INFORMATION_SCHEMA...")
    
    # Query details: Pulls the schema name, view identity, and raw text DDL query 
    # filtering down to specific functional business schemas.
    view_query = """
        SELECT TABLE_SCHEMA, TABLE_NAME, VIEW_DEFINITION 
        FROM INFORMATION_SCHEMA.VIEWS
        WHERE TABLE_SCHEMA IN ('HumanResources', 'Person', 'Production', 'Purchasing', 'Sales', 'dbo')
    """
    cursor.execute(view_query)
    
    for schema, name, definition in cursor.fetchall():
        if definition:
            # File命名 convention: SchemaName.ViewName.sql
            filename = f"{schema}.{name}.sql"
            filepath = os.path.join(OUTPUT_BASE_DIR, 'views', filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(definition)
            extracted_counts['views'] += 1

    # -------------------------------------------------------------------------
    # PHASE 2: EXTRACTION OF ROUTINES (Procedures & Functions)
    # -------------------------------------------------------------------------
    print("[*] Harvesting Procedures and Functions from INFORMATION_SCHEMA...")
    
    # Query details: Gathers both functions and procedures. 
    # ROUTINE_TYPE tells us if it's a 'PROCEDURE' or a 'FUNCTION'.
    routine_query = """
        SELECT ROUTINE_SCHEMA, ROUTINE_NAME, ROUTINE_TYPE, ROUTINE_DEFINITION 
        FROM INFORMATION_SCHEMA.ROUTINES
        WHERE ROUTINE_SCHEMA IN ('HumanResources', 'Person', 'Production', 'Purchasing', 'Sales', 'dbo')
    """
    cursor.execute(routine_query)
    
    for schema, name, r_type, definition in cursor.fetchall():
        # Encrypted or structural placeholder routines containing empty definitions are bypassed
        if not definition:
            continue
        
        filename = f"{schema}.{name}.sql"
        
        if r_type == 'PROCEDURE':
            folder = 'stored_procedures'
            extracted_counts['stored_procedures'] += 1
        else: 
            # DIALECT SUB-SORTING: MSSQL functions can return a single data primitive (SCALAR)
            # or an entire dataset matrix (TABLE). Open-source engines translate these completely differently.
            if "RETURNS TABLE" in definition.upper() or "TABLE" in definition.upper():
                folder = 'functions_table'
                extracted_counts['functions_table'] += 1
            else:
                folder = 'functions_scalar'
                extracted_counts['functions_scalar'] += 1
        
        filepath = os.path.join(OUTPUT_BASE_DIR, folder, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(definition)

    # -------------------------------------------------------------------------
    # PHASE 3: EXTRACTION OF TRIGGERS (Via fallback sys lookup)
    # -------------------------------------------------------------------------
    print("[*] Harvesting structural table triggers...")
    
    # Query details: Table triggers aren't kept in standard INFORMATION_SCHEMA maps. 
    # We must traverse the system metadata core (`sys.triggers`), join onto structural tables 
    # to find schemas, and map into `sys.sql_modules` to grab the source text definition.
    trigger_query = """
        SELECT sch.name, tr.name, mod.definition
        FROM sys.triggers tr
        INNER JOIN sys.objects obj ON tr.object_id = obj.object_id
        INNER JOIN sys.schemas sch ON obj.schema_id = sch.schema_id
        INNER JOIN sys.sql_modules mod ON tr.object_id = mod.object_id
    """
    try:
        cursor.execute(trigger_query)
        for schema, name, definition in cursor.fetchall():
            if definition:
                filename = f"{schema}.{name}.sql"
                filepath = os.path.join(OUTPUT_BASE_DIR, 'triggers', filename)
                
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(definition)
                extracted_counts['triggers'] += 1
    except Exception:
        # Wrap in try-except block so if security privileges block sys catalog inspection,
        # the migration engine skips cleanly rather than crashing out mid-pipeline.
        pass 

    # -------------------------------------------------------------------------
    # PRINT RESULTS
    # -------------------------------------------------------------------------
    print("\n" + "-" * 50)
    print(" FINAL EXTRACTION SUMMARY")
    print("-" * 50)
    for folder, count in extracted_counts.items():
        # Clean folder naming output layout display formats
        clean_label = folder.replace('_', ' ').title()
        print(f" -> {clean_label:<30}: {count} files extracted")
    print("-" * 50)
    print(f"[+] Assets safely synchronized at: {OUTPUT_BASE_DIR}\n")

    # Resource cleanup
    cursor.close()
    conn.close()

if __name__ == "__main__":
    main()